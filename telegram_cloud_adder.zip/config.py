API_ID = 123456
API_HASH = "your_api_hash"
